To setup prometheus run the bash script "promethues.sh"
then setup grafana on the same machine, run 'grafana-setup.sh' (take a t2.medium machine)
then lauch an another machine then setup db and exporter